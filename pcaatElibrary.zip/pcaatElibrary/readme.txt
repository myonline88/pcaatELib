1. Download XAMPP and Install it
2. put this directory inside the  htdocs folder
3. open the MyAdmin UI and create a database named 'pcaatelib'
4. import the 'pcaatelib.sql'
5. Open the XAMPP UI, create an alias 'pcaat'
6. copy and paste the location of the folder that contains all the files
7. open a browser, type in URL address bar: 127.0.0.1/pcaat/home.php